import os
import pdfplumber  # For reading PDFs
import pandas as pd
import numpy as np
import torch
from transformers import BertTokenizer, BertModel
from sklearn.metrics.pairwise import cosine_similarity

# Load Pretrained BERT Model and Tokenizer
tokenizer = BertTokenizer.from_pretrained("bert-base-uncased")
model = BertModel.from_pretrained("bert-base-uncased")

# Function to Preprocess Text
def preprocess_text(text):
    text = text.lower()
    text = ''.join([char for char in text if char.isalnum() or char.isspace()])
    return text

# Function to Extract Feature Vectors
def get_bert_embeddings(text):
    inputs = tokenizer(text, return_tensors="pt", truncation=True, padding=True, max_length=512)
    with torch.no_grad():
        outputs = model(**inputs)
    return outputs.last_hidden_state.mean(dim=1).numpy()

# Function to Read Text from PDFs or TXT Files
def load_resumes_from_folder(folder_path):
    resume_texts = []
    for file in os.listdir(folder_path):
        file_path = os.path.join(folder_path, file)
        if file.endswith(".txt"):
            with open(file_path, "r", encoding="utf-8") as f:
                resume_texts.append(f.read())
        elif file.endswith(".pdf"):
            with pdfplumber.open(file_path) as pdf:
                text = "\n".join([page.extract_text() for page in pdf.pages if page.extract_text()])
                resume_texts.append(text)
    return resume_texts

# Load Resumes and Job Description
resume_texts = load_resumes_from_folder("/Users/krishnanandini/Documents/S8/MFML/project/code/resumes")  # Change to actual path
job_description = open("/Users/krishnanandini/Documents/S8/MFML/project/code/JD.txt", "r", encoding="utf-8").read()  # Load JD from file

# Preprocess Text
preprocessed_resumes = [preprocess_text(resume) for resume in resume_texts]
preprocessed_job = preprocess_text(job_description)

# Convert to Feature Vectors
resume_vectors = np.array([get_bert_embeddings(resume) for resume in preprocessed_resumes])
job_vector = get_bert_embeddings(preprocessed_job)

# Compute Similarity Scores
similarity_scores = cosine_similarity(resume_vectors.reshape(len(resume_vectors), -1),
                                      job_vector.reshape(1, -1))

# Ranking Resumes
ranked_indices = np.argsort(-similarity_scores.flatten())  # Descending order

# Display Results
print("Top shortlisted resumes:")
for rank, resume_idx in enumerate(ranked_indices[:3]):  # Shortlist top 3 resumes
    print(f"Rank {rank + 1}: Resume {resume_idx + 1} (Score: {similarity_scores[resume_idx][0]:.4f})")
